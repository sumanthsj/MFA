package com.example.mfa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MfaApplicationTests {

	@Test
	void contextLoads() {
	}

}
